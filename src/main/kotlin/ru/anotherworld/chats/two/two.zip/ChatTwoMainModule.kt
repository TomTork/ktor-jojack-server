package ru.anotherworld.chats.two

import org.koin.dsl.module
import org.litote.kmongo.coroutine.coroutine
import org.litote.kmongo.reactivestreams.KMongo
import ru.anotherworld.chats.data.MessageDataSource
import ru.anotherworld.chats.data.MessageDataSourceImpl
import ru.anotherworld.chats.room.RoomController

fun twoModule(name: String) = module {
    single {
        KMongo.createClient().coroutine.getDatabase(name)
    }
    single<MessageDataSource> {
        MessageDataSourceImpl(get())
    }
    single {
        RoomController(get())
    }
}