package ru.anotherworld.chats.two

import io.ktor.websocket.*

data class ChatTwoMember(
    val username: String,
    val sessionId: String,
    val socket: WebSocketSession,
    val oKey1: String,
    val oKey2: String
)