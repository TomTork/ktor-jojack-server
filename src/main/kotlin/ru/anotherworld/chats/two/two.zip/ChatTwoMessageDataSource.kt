package ru.anotherworld.chats.two

import org.litote.kmongo.coroutine.CoroutineDatabase
import ru.anotherworld.chats.data.model.Message

class ChatTwoMessageDataSource(
    private val db: CoroutineDatabase
) {
    private val messages = db.getCollection<ChatTwoMessage>()

    suspend fun getAllMessages(): List<ChatTwoMessage> {
        return messages.find().descendingSort(ChatTwoMessage::timestamp).toList()
    }

    suspend fun insertMessage(message: ChatTwoMessage) {
        messages.insertOne(message)
    }
}