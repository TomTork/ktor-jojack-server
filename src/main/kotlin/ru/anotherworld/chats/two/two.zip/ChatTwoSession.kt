package ru.anotherworld.chats.two

data class ChatTwoSession(
    val username: String,
    val sessionId: String,
    val nameDB: String
)