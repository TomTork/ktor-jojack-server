package ru.anotherworld.chats.two

import io.ktor.websocket.*
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import ru.anotherworld.chats.data.model.Message
import ru.anotherworld.chats.room.Member
import ru.anotherworld.chats.room.MemberAlreadyExistsException
import java.util.concurrent.ConcurrentHashMap

class ChatTwoRoomController(
    private val messageDataSource: ChatTwoMessageDataSource
) {
    private val members = ConcurrentHashMap<String, ChatTwoMember>()

    fun onJoin(
        username: String,
        sessionId: String,
        socket: WebSocketSession,
        oKey1: String,
        oKey2: String
    ) {
        if(members.containsKey(username)){
            throw MemberAlreadyExistsException()
        }
        members[username] = ChatTwoMember(username, sessionId, socket, oKey1, oKey2)
    }

    suspend fun sendMessage(senderUsername: String, message: String, oKey1: String, oKey2: String){
        var ready = true
        members.values.forEach { member ->
            val messageEntity = ChatTwoMessage(
                text = message,
                username = senderUsername,
                timestamp = System.currentTimeMillis(),
                oKey1 = oKey1,
                oKey2 = oKey2
            )
            if (ready){
                messageDataSource.insertMessage(messageEntity)
                ready = false
            }
            val parsedMessage = Json.encodeToString(messageEntity)
            member.socket.send(Frame.Text(parsedMessage))
        }
    }

    suspend fun getAllMessages(): List<ChatTwoMessage>{
        return messageDataSource.getAllMessages()
    }

    suspend fun tryDisconnect(username: String){
        members[username]?.socket?.close()
        if (members.containsKey(username)){
            members.remove(username)
        }
    }
}